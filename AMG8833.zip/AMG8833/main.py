#-*- coding:utf-8 -*-
# AUTHOR:   foucher
# FILE:     skeleton.py
# ROLE:     TODO (some explanation)
# CREATED:  2020-12-08 21:43:08
# MODIFIED: 2020-12-08 21:43:08

# Logs

from logger import getLogger
log = getLogger(__file__)


# Imports

import json
import math
import numpy as np
import pygame
import serial
import sys

from colour import Color
from pygame.locals import Rect
from scipy.interpolate import griddata


# Global variables


# Class declarations

class Viewer(object):

    def __init__(self, 
                    title='AMG8833', serialDeviceFile='/dev/ttyACM0', interpolation=4,
                    mintemp=18, maxtemp=28,
                    smooth=False,
                    showColorScale=False,
                ):

        self.title = title

        self.serialDeviceFile = serialDeviceFile

        # 1 : 8x8
        # 2 : 16x16
        # 4 : 32x32
        self.interpolation = min(interpolation, 16)

        # low range of the sensor (this will be blue on the screen)
        self.mintemp = mintemp # 18.0

        # high range of the sensor (this will be red on the screen)
        self.maxtemp = maxtemp # 28.0

        log.debug('(mintemp, maxtemp) = (%d, %d)' % (self.mintemp, self.maxtemp))

        self.smooth = smooth

        # how many color values we can have
        self.colordepth = 1024

        # pylint: disable=invalid-slice-index
        self.points = [(math.floor(ix / 8), (ix % 8)) for ix in range(0, 64)]

        #self.grid_x, self.grid_y = np.mgrid[0:7:32j, 0:7:32j]
        x = np.linspace(0, 7, 8 * self.interpolation)
        y = np.linspace(0, 7, 8 * self.interpolation)
        self.grid_x, self.grid_y = np.meshgrid(x, y)[::-1]
        # pylint: enable=invalid-slice-index

        # sensor is an 8x8 grid so lets do a square
        self.height = 640
        self.width = self.height

        # the list of colors we can choose from
        blue = Color("indigo")
        self.colors = list(blue.range_to(Color("red"), self.colordepth))

        # create the array of colors
        self.colors = [(int(c.red * 255), int(c.green * 255), int(c.blue * 255)) for c in self.colors]

        self.displayPixelWidth = (4/self.interpolation) * self.width / 32 
        self.displayPixelHeight = (4/self.interpolation) * self.height / 32

        self.showColorScale = showColorScale
        self.margin = 0
        if self.showColorScale:
            self.margin = 45



    # some utility functions
    def constrain(self, val, min_val, max_val):
        return min(max_val, max(min_val, val))


    def map_value(self, x, in_min, in_max, out_min, out_max):
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

    # this function will create a pygame window and call main_loop.
    def runPyGame(self):

        # initialize the pygame app.
        pygame.init()

        # define a window title.
        pygame_window_title = self.title

        # set window title to the pygame app window.
        pygame.display.set_caption(pygame_window_title)

        # define a tuple to store screen size.
        square_width = self.width # 600
        screen_size = (self.margin+square_width, square_width)
        # set the pygame window screen size.
        screen = pygame.display.set_mode(screen_size)

        # set the pygame window background color.
        #screen.fill(pygame.Color('blue'))

        # create a pygame.font.Font object to represent the text Font.
        #f = pygame.font.SysFont(name = 'SF', size = 50, bold = True, italic = True)
        # generate text, the first parameter specifies the text content. 
        # the second parameter specifies whether the text font is antialias or not.
        # the third parameter specifies the text color.
        # the fourth parameter specifies the text background color.
        #text = f.render("Hello World", False, pygame.Color('red'), pygame.Color('green'))

        # get the rectangle area coordinates of the display text object.
        #textRect = text.get_rect()

        # define the text rectangle center point coordinates.
        #center_coordinates = (300, 300)
        #textRect.center = center_coordinates

        # draw the prepared text on the main screen.
        #screen.blit(text,textRect)

        self.main_loop(screen)


    def drawColorScale(self, screen):
        font = pygame.font.Font(None, 22)                            # フォントの設定(55px)

        temps = list(range((int)(self.maxtemp), (int)(self.mintemp), -1))

        pixels = [self.map_value(t, self.mintemp, self.maxtemp, 0, self.colordepth - 1) for t in temps]

        ymiddle = (int)(self.height/2)

        dx = 25
        dy = 50

        xstart = 10
        ystart = ymiddle - (int)(len(pixels)/2) * dy

        nn=0
        for nn in range(len(pixels)): #nnは配列の中の番号を指定
            # 左上座標(10,10)、幅50px、高さ50pxの長方形を線幅5pxの緑色(R=0, G=80, B=0)で描く
            #pygame.draw.rect(screen,(0,250,0),Rect(10,10,50,50),5)     # 四角形を描画(塗りつぶしなし)
            pygame.draw.rect(screen,(self.colors[int(pixels[nn])]), Rect(xstart, ystart+dy*nn, dx, dy))    # 四角形を描画(塗りつぶし)
            text = font.render(str(temps[nn]), True, (255,255,255))      # 描画する文字列の設定
            screen.blit(text, [xstart+5, ystart+(int)(-5+dy/2)+dy*nn])                           # 文字列の表示位置
            nn+=1


    # the main_loop function is used the monitor and handle user triggered event. 
    def main_loop(self, screen):

        ser = serial.Serial(self.serialDeviceFile, timeout=0.1)
        #ser.flushInput()
        log.debug('self.serialDeviceFile = %s' % self.serialDeviceFile)

        if self.showColorScale:
            self.drawColorScale(screen)

        # implement the feature that when clicking the pygame window close button ("X") on window title bar then it will exit the window. 
        # Almost all pygame application will use this kinds of code.
        while True:

            # Loop to get events and listen for event status.
            for event in pygame.event.get():

                # if user click the window close button.
                if event.type == pygame.QUIT: 

                    # quit pygame.
                    pygame.quit()

                    # quit the application.
                    #sys.exit()
                    return

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        log.debug('ESCAPE!')
                        pygame.quit()
                        return


            #ser_bytes = ser.readline()
            #decoded_bytes = float(ser_bytes[0:len(ser_bytes)-2].decode("utf-8"))
            s = ser.readline().strip()
            #log.debug('s = ')
            #log.debug(s)

            if not s:
                pygame.display.update() # refresh the screen.
                continue

            kw = {}
            try:
                kw = json.loads(s)
            except Exception as e:
                log.exception(e)
                pygame.display.update() # refresh the screen.
                continue

            #log.debug('kw = ')
            #log.debug(kw)
            if kw.get('TYPE', '') != 'DET':
                pygame.display.update() # refresh the screen.
                continue

            data = kw.get('AMG8833', [])

            if not data:
                pygame.display.update() # refresh the screen.
                continue

            #log.debug(data)

            if self.smooth:
                tl = data[0][0] # 左上
                bl = data[0][7] # 左下
                tr = data[7][0] # 右上
                br = data[7][7] # 右下
                a = [tl, bl, tr, br]
                a.remove(max(a))
                avg = sum(a)/3
                self.mintemp = (int)(avg-1)

                arr = np.array(data)
                self.maxtemp = arr.max() + 1
                log.debug('(mintemp, maxtemp) = (%d, %d)' % (self.mintemp, self.maxtemp))

                if self.showColorScale:
                    screen.fill((0,0,0))                                     # 画面を黒色に塗りつぶし
                    self.drawColorScale(screen)

            # read the pixels
            pixels = []
            #for row in sensor.pixels:
            for row in data:
                pixels = pixels + row
            pixels = [self.map_value(p, self.mintemp, self.maxtemp, 0, self.colordepth - 1) for p in pixels]

            # perform interpolation
            bicubic = griddata(self.points, pixels, (self.grid_x, self.grid_y), method="cubic")

            # draw everything
            for ix, row in enumerate(bicubic):
                for jx, pixel in enumerate(row):
                    pygame.draw.rect(
                        screen,
                        self.colors[self.constrain(int(pixel), 0, self.colordepth - 1)],
                        (
                            self.margin+self.displayPixelHeight * ix,
                            self.displayPixelWidth * jx,
                            self.displayPixelHeight,
                            self.displayPixelWidth,
                        ),
                    )

            #pygame.display.flip() # refresh the screen.
            pygame.display.update() # refresh the screen.


# Function declarations

# Main body


def main():

    import argparse
    from argparse import RawTextHelpFormatter
    parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter)

    parser.add_argument('-v', '--verbose',
        dest='verbose', help='increase verbosity',
        action='store_true')

    parser.add_argument('-t', '--title',
        dest='title', help='タイトル',
        type=str, nargs='?', default='AMG8833',
        required=False)

    parser.add_argument('--showcolorscale',
        dest='showcolorscale', help='緑色を表示する',
        action='store_true')

    parser.add_argument('-i', '--interpolation',
        dest='interpolation', help='interpolation (1→8, 2→16, 4→32). 最大: 16',
        type=int, nargs='?', default=4,
        required=False)

    parser.add_argument('--mintemp',
        dest='mintemp', help='最低温度',
        type=int, nargs='?', default=18,
        required=False)

    parser.add_argument('--maxtemp',
        dest='maxtemp', help='最高温度',
        type=int, nargs='?', default=28,
        required=False)

    parser.add_argument('--smooth',
        dest='smooth', help='最低温度や最高温度を自動的に調整する',
        action='store_true')

    parser.add_argument('-s', '--serial',
        dest='serial', help='シリアル名 (例：COM4, /dev/ttyACM0)',
        type=str, nargs='?', default='/dev/ttyACM0',
        required=False)

    parser.add_argument('-a', '--args',
        dest='args', help="""Set arguments.
Format: key=value,key=value,etc...

Available Keys:
- key1
    explanation1
- ...

Example: -a key1=value

""",
        nargs='?',
        metavar=('key=value,...',),
        default='')

    args = parser.parse_args()

    if args.args:
        kw = dict(item.split("=") for item in args.args.split(","))
        for k,v in kw.items():
            try:
                v = float(v)
                kw[k] = v
                continue
            except: pass
            try:
                v = int(v)
                kw[k] = v
                continue
            except: pass

    kw = {
        'title': args.title,
        'interpolation': args.interpolation,
        'serialDeviceFile': args.serial,
        'mintemp': args.mintemp,
        'maxtemp': args.maxtemp,
        'smooth': args.smooth,
        'showColorScale': args.showcolorscale,
    }
    viewer = Viewer(**kw)
    viewer.runPyGame()

    # END OF MAIN



if __name__ == "__main__":
    log.info("START...")
    main()
    log.info("...END.")
