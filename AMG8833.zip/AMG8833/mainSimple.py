#-*- coding:utf-8 -*-
# AUTHOR:   foucher
# FILE:     skeleton.py
# ROLE:     TODO (some explanation)
# CREATED:  2020-12-08 21:43:08
# MODIFIED: 2020-12-08 21:43:08

# Logs

#import logging
#logging.basicConfig(
#    format='%(asctime)s:%(levelname)s:%(name)s: %(message)s',
#    datefmt='%y/%m/%d %H:%M:%S')

#loggerName = __file__.split('.')[0]

#from logger import createHandler
#handler = createHandler(loggerName)
#log = logging.getLogger(loggerName)
#log.addHandler(handler)
#
#logging.root.setLevel(logging.DEBUG)
##logging.root.setLevel(logging.INFO)


from logger import getLogger
#log = getLogger(loggerName)
log = getLogger(__file__)

# Imports

import json
import math
import numpy as np
import pygame
import serial
import sys

from colour import Color
from scipy.interpolate import griddata


# Global variables

# low range of the sensor (this will be blue on the screen)
MINTEMP = 18.0

# high range of the sensor (this will be red on the screen)
MAXTEMP = 28.0

# how many color values we can have
COLORDEPTH = 1024

# pylint: disable=invalid-slice-index
points = [(math.floor(ix / 8), (ix % 8)) for ix in range(0, 64)]
grid_x, grid_y = np.mgrid[0:7:32j, 0:7:32j]
# pylint: enable=invalid-slice-index

# sensor is an 8x8 grid so lets do a square
height = 640
width = height

# the list of colors we can choose from
blue = Color("indigo")
colors = list(blue.range_to(Color("red"), COLORDEPTH))

# create the array of colors
colors = [(int(c.red * 255), int(c.green * 255), int(c.blue * 255)) for c in colors]

displayPixelWidth = width / 30 
displayPixelHeight = height / 30 


# Class declarations


# Function declarations

# some utility functions
def constrain(val, min_val, max_val):
    return min(max_val, max(min_val, val))


def map_value(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

# this function will create a pygame window and call main_loop.
def runPyGame(title='AMG8833', serialDeviceFile='/dev/ttyACM0'):

    # initialize the pygame app.
    pygame.init()

    # define a window title.
    pygame_window_title = title

    # set window title to the pygame app window.
    pygame.display.set_caption(pygame_window_title)
    
    # define a tuple to store screen size.
    square_width = width # 600
    screen_size = (square_width, square_width)
    # set the pygame window screen size.
    screen = pygame.display.set_mode(screen_size)

    # set the pygame window background color.
    #screen.fill(pygame.Color('blue'))

    # create a pygame.font.Font object to represent the text Font.
    #f = pygame.font.SysFont(name = 'SF', size = 50, bold = True, italic = True)
    # generate text, the first parameter specifies the text content. 
    # the second parameter specifies whether the text font is antialias or not.
    # the third parameter specifies the text color.
    # the fourth parameter specifies the text background color.
    #text = f.render("Hello World", False, pygame.Color('red'), pygame.Color('green'))

    # get the rectangle area coordinates of the display text object.
    #textRect = text.get_rect()
    
    # define the text rectangle center point coordinates.
    #center_coordinates = (300, 300)
    #textRect.center = center_coordinates
    
    # draw the prepared text on the main screen.
    #screen.blit(text,textRect)
    
    main_loop(screen, serialDeviceFile)


# the main_loop function is used the monitor and handle user triggered event. 
def main_loop(screen, serialDeviceFile='/dev/ttyACM0'):
    
    ser = serial.Serial(serialDeviceFile, timeout=0.1)
    ser.flushInput()

    # implement the feature that when clicking the pygame window close button ("X") on window title bar then it will exit the window. 
    # Almost all pygame application will use this kinds of code.
    while True:
        
        # Loop to get events and listen for event status.
        for event in pygame.event.get():
            
            # if user click the window close button.
            if event.type == pygame.QUIT: 
                               
                # quit pygame.
                pygame.quit()
                
                # quit the application.
                #sys.exit()
                return

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    log.debug('ESCAPE!')
                    pygame.quit()
                    return
                

        #ser_bytes = ser.readline()
        #decoded_bytes = float(ser_bytes[0:len(ser_bytes)-2].decode("utf-8"))
        s = ser.readline().strip()
        #log.debug('s = ')
        #log.debug(s)

        if not s:
            pygame.display.update() # refresh the screen.
            continue

        kw = {}
        try:
            kw = json.loads(s)
        except Exception as e:
            log.exception(e)
            pygame.display.update() # refresh the screen.
            continue

        #log.debug('kw = ')
        #log.debug(kw)
        if kw.get('TYPE', '') != 'DET':
            pygame.display.update() # refresh the screen.
            continue

        data = kw.get('AMG8833', [])

        if not data:
            pygame.display.update() # refresh the screen.
            continue

        #log.debug(data)

        # read the pixels
        pixels = []
        #for row in sensor.pixels:
        for row in data:
            pixels = pixels + row
        pixels = [map_value(p, MINTEMP, MAXTEMP, 0, COLORDEPTH - 1) for p in pixels]

        # perform interpolation
        bicubic = griddata(points, pixels, (grid_x, grid_y), method="cubic")

        # draw everything
        for ix, row in enumerate(bicubic):
            for jx, pixel in enumerate(row):
                pygame.draw.rect(
        #            lcd,
                    screen,
                    colors[constrain(int(pixel), 0, COLORDEPTH - 1)],
                    (
                        displayPixelHeight * ix,
                        displayPixelWidth * jx,
                        displayPixelHeight,
                        displayPixelWidth,
                    ),
                )

        #pygame.display.flip() # refresh the screen.
        pygame.display.update() # refresh the screen.

# Main body


def main():

    import argparse
    from argparse import RawTextHelpFormatter
    parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter)

    parser.add_argument('-v', '--verbose',
        dest='verbose', help='increase verbosity',
        action='store_true')

    parser.add_argument('-a', '--args',
        dest='args', help="""Set arguments.
Format: key=value,key=value,etc...

Available Keys:
- key1
    explanation1
- ...

Example: -a key1=value

""",
        nargs='?',
        metavar=('key=value,...',),
        default='')

    args = parser.parse_args()

    if args.args:
        kw = dict(item.split("=") for item in args.args.split(","))
        for k,v in kw.items():
            try:
                v = float(v)
                kw[k] = v
                continue
            except: pass
            try:
                v = int(v)
                kw[k] = v
                continue
            except: pass

    runPyGame()

    # END OF MAIN



if __name__ == "__main__":
    log.info("START...")
    main()
    log.info("...END.")
